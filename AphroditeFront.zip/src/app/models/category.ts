export interface Category {
    nomCategorie:string ; 
    description: string ;  
}